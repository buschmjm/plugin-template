﻿---
name: Yorch Armory
description: Yorch's Armory expands the game's core arsenal by adding multiple variations of armor and weapons forged from copper, iron, silver, bronze & cobalt.(More to come)
author: ElJamonDeYorch
---

   # My Mod

   My Mod adds weapons and armors to you Hytale world.
